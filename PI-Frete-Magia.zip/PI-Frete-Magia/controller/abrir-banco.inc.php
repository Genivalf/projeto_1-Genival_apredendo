<?php
 $conexao->select_db($nomeDoBanco);