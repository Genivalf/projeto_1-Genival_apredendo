<?php
 $servidor      = "localhost";
 $usuario       = "root";
 $senha         = "";
          
 $nomeDoBanco   = "PI_Frete_Magia";
 $nomeDaTabela  = "cadastrar_usuario";
 