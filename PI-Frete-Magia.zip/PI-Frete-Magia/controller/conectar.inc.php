<?php
 $conexao = new mysqli($servidor, $usuario, $senha);